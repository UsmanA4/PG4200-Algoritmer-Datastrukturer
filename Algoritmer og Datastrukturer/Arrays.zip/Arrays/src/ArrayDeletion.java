import java.util.*;
public class ArrayDeletion{
    public static void main(String[] args) {
// TODO Auto-generated method stub
        int arr[] = {1254, 1458, 5687, 1457, 4554, 5445, 7524};
        int n = arr.length;


        int pos = 3;
        System.out.println("the position of the number which is to be deleted  is " + pos);

        for(int i=pos;i<n-1;i++)
        {
            arr[i]=arr[i+1];
        }
        n=n-1;

        System.out.println("\nOn deleting new array we get is\n");
        for(int i=0;i<n;i++)
        {
            System.out.println("arr["+i+"] = "+arr[i]);
        }
    }
}
