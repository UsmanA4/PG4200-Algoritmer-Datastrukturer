import java.util.*;

public class ArraySearch {

    public static void main(String args[]) {
        // taking user input
        int arr[] = {1254, 1458, 5687, 1457, 4554, 5445, 7524};
        int n = arr.length;

        // asking user for target element
        Scanner sc = new Scanner(System.in);
        System.out.println("Enter target element:");
        int target = sc.nextInt();

        // using linear search to find element
        int index = Search(n, arr, target);

        // printing result
        System.out.println("The array is as follows:\n" + Arrays.toString(arr));

        if (index == -1) System.out.println(
                "Sorry, element not found"
        ); else System.out.println("The element is present at index " + index);
    }

    public static int Search(int N, int[] arr, int target) {
        // using for loop to traverse the array
        for (int i = 0; i < N; i++) {
            // if target is found return
            if (arr[i] == target) return i + 1;
        }
        // if the target is not present return
        return -1;
    }
}