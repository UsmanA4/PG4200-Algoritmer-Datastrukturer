import java.util.Arrays;
public class ArrayInsertion{
    public static void main(String[] args) {
// TODO Auto-generated method stub
        int arr[] = {1254, 1458, 5687, 1457, 4554, 5445, 7524};
        int n = arr.length;
        int newArr[] = new int[n+1];
        int value = 2000;
        System.out.println(Arrays.toString(arr));
        for(int i = 0; i<n; i++) {
            newArr[i] = arr[i];
        }
        newArr[n] = value;
        System.out.println(Arrays.toString(newArr));
    }
}