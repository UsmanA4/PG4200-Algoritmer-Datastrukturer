import java.util.Stack;

public  class Question2{

    /*Create a stack and made it public */
    public Stack<Integer> stack = new Stack<>();

    /*initializing a variable for the minimum element in stack and made it public*/
    public int minElement;

    public int push(Integer x) {
        if (stack.isEmpty()) {
            minElement = x;
            stack.push(x);
            System.out.println("Number pushed to the stack: " + x);
            return -1;
        }

        minElement = x;
        stack.push(x);

        System.out.println("Number pushed to stack: " + x);
        return x;
    }

    public int getMin() {
        if (stack.isEmpty()) {
            System.out.println("The stack is empty");
            return -1;
        } else {
            System.out.println("The minimum element in stack:"+minElement);
            return minElement;

        }

    }
    /* Pop method deletes the element from stack*/
    public int pop() {
        if (stack.isEmpty()) {
            System.out.println("Stack is empty");
            return -1;
        }

        System.out.print("The element is removed from top: ");

        System.out.println(minElement);
        return minElement;
    }


    /*Create a driver code to check if the methods works as intended below:*/

    public static void main(String[] args) {
        Question2 stack = new Question2();
        stack.push(7);
        stack.push(6);
        stack.pop();
        stack.getMin();
    }
}
