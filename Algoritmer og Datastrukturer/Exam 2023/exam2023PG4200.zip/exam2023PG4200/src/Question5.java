public class Question5 {

    public int recursiveVersion(int num ){
        /*in the recursive method we created an if statement ,  checks if num <= 1 it returns the num*/
        if (num <=1){
            return num;
        }
        /*recursively call the method and adds the result. */
        return recursiveVersion(num-1)+recursiveVersion(num-2);
    }


    public int iterativeVersion(int n){
        /*initializing the variable fib1 and fib2 equal to 1*/
        int fib1=1;
        int fib2=1;

        /*use for loop */
        for (int i =3 ; i <=n ; i++) {
            int fibn = fib1;
            /*fib(1) is calculated by adding fib2  and fib (1)*/
            fib1=fib2 + fib1;
            /* fib1 is equal to fib1 which is 1*/
            fib2=fibn;
        }
        return fib1;
    }

    public static void main(String[] args) {
        Question5 q = new Question5();

        /*Here we iterate from 1 to 5 to print the fibonacci numbers using both recursion and iterative methods*/
        System.out.println("Recursive :");
        for (int i = 1; i <=5 ; i++) {

            System.out.println(q.recursiveVersion(i));
        }
        System.out.println("Iterative:");
        for (int i = 1; i <=5 ; i++) {

            System.out.println(q.iterativeVersion(i));
        }

    }


    /*Which is more efficient Iteration or Recursion?

      Recursion is when a function calls itself in an infinite loop to solve a problem. The time complexity of recursion is
      o(n^2) which means that the function calls itself every time n grows. Suppose we have we want to calculate the fib(5) when calculating this we have
      to call the function about four times since it requires the fib(3) and fib(4) and for fib (3) we need the values for fib(1) and fib(2) and this is
      a waste of time. If n grows it will become more and more complex and this will not only take much time but a lot of space too.

      Iteration on the other hand uses loops to solve the problem. it doesn't require any computation for solving a problem every time, instead
      it uses two fibonacci numbers and uses the previous values to calculate the new value , this will continue until fib(n) is found.
      The time complexity of the iterative method is O(N) , it preforms a linear calculation as the input n grows.
      In this way it avoids using recursive calls and in this way it avoids unnecessary redundant calculations. They have both the same space complexity
      since Iteration uses a linear time complexity it is faster and more efficient than recursion.
    */
}
